# expand_disk
---

See [role_vmware_grow_vg](https://dev.azure.com/centerpoint-automation/CNP.Automation/_git/role_lnx_modify_disk) for details

